package com.example

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BgColor = Color(0xFF0A0A0A)
val CardColor = Color(0xFF1A1A1A)
val PowerOffColor = Color(0xFF4A4A4A)
val PowerOnColor = Color(0xFF00FF7F)
val AccentOrange = Color(0xFFFF6B35)
val HighlightCyan = Color(0xFF00D9FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = BgColor,
                    surface = CardColor,
                    primary = PowerOnColor,
                    secondary = AccentOrange,
                    tertiary = HighlightCyan
                )
            ) {
                VpnAppScreen()
            }
        }
    }
}

@Composable
fun VpnAppScreen() {
    var isVpnOn by remember { mutableStateOf(false) }
    var selectedScreen by remember { mutableStateOf(0) }
    
    Scaffold(
        bottomBar = {
            BottomNav(selectedScreen) { selectedScreen = it }
        },
        containerColor = BgColor
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (selectedScreen) {
                0 -> DashboardScreen(isVpnOn) { isVpnOn = it }
                1 -> ServersScreen()
                2 -> SpeedTestScreen()
                3 -> BypassScreen()
            }
        }
    }
}

@Composable
fun DashboardScreen(isVpnOn: Boolean, onToggle: (Boolean) -> Unit) {
    val context = LocalContext.current
    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = Intent(context, StealthVpnService::class.java).apply {
                action = "START"
            }
            context.startService(intent)
            onToggle(true)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text("StealthShield VPN", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)

        // Status Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CardColor),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Column(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isVpnOn) "CONNECTED" else "DISCONNECTED",
                    color = if (isVpnOn) PowerOnColor else Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("00:00:00", color = Color.White, fontSize = 32.sp) // Timer mock
            }
        }

        // Power Button
        PowerButton(isVpnOn) {
            if (!isVpnOn) {
                val intent = VpnService.prepare(context)
                if (intent != null) {
                    vpnLauncher.launch(intent)
                } else {
                    val startIntent = Intent(context, StealthVpnService::class.java).apply { action = "START" }
                    context.startService(startIntent)
                    onToggle(true)
                }
            } else {
                val stopIntent = Intent(context, StealthVpnService::class.java).apply { action = "STOP" }
                context.startService(stopIntent)
                onToggle(false)
            }
        }

        // Stats Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CardColor),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Download", tint = HighlightCyan)
                    Text(if (isVpnOn) "45.2 Mbps" else "0.0 Mbps", color = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Upload", tint = AccentOrange)
                    Text(if (isVpnOn) "12.8 Mbps" else "0.0 Mbps", color = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = Color.LightGray)
                    Text("Frankfurt", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun PowerButton(isVpnOn: Boolean, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isVpnOn) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val color by animateColorAsState(if (isVpnOn) PowerOnColor else PowerOffColor, label = "color")

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(150.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.2f))
            .clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(color)
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = "Power",
                tint = BgColor,
                modifier = Modifier.size(64.dp)
            )
        }
    }
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = CardColor) {
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, "Dashboard") },
            label = { Text("Dashboard") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PowerOnColor, unselectedIconColor = Color.Gray, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.AutoMirrored.Filled.List, "Servers") },
            label = { Text("Servers") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PowerOnColor, unselectedIconColor = Color.Gray, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Speed, "Speed Test") },
            label = { Text("Speed Test") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PowerOnColor, unselectedIconColor = Color.Gray, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = selected == 3,
            onClick = { onSelect(3) },
            icon = { Icon(Icons.Default.Security, "Bypass") },
            label = { Text("Bypass") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PowerOnColor, unselectedIconColor = Color.Gray, indicatorColor = Color.Transparent)
        )
    }
}

@Composable
fun ServersScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Select Server", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        
        Text("FREE (Ad Supported, 10 Mbps)", color = Color.Gray)
        ServerItem("Turkey - Istanbul", Icons.Default.Public, true)
        ServerItem("Germany - Frankfurt", Icons.Default.Public, true)
        
        Spacer(modifier = Modifier.height(24.dp))
        Text("PRO (No Limits)", color = AccentOrange)
        ServerItem("Japan - Tokyo", Icons.Default.Star, false)
        ServerItem("USA - New York", Icons.Default.Star, false)
        
        Spacer(modifier = Modifier.weight(1f))
        ProBanner()
    }
}

@Composable
fun ServerItem(name: String, icon: ImageVector, isFree: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardColor),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { }
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = if (isFree) Color.Gray else HighlightCyan)
            Spacer(modifier = Modifier.width(16.dp))
            Text(name, color = Color.White)
        }
    }
}

@Composable
fun ProBanner() {
    Card(
        colors = CardDefaults.cardColors(containerColor = HighlightCyan.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable { }
    ) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Unlock PRO", color = HighlightCyan, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("1-Year Plan: \$17.88", color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Surface(color = AccentOrange, shape = RoundedCornerShape(8.dp)) {
                Text(
                    "Best Value - 50% Off", 
                    color = Color.White, 
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun SpeedTestScreen() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Speed Test Dashboard", color = Color.Gray, fontSize = 20.sp)
    }
}

@Composable
fun BypassScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Censorship Bypass Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Protocol overrides for highly restrictive networks", color = Color.Gray)
        Spacer(modifier = Modifier.height(24.dp))
        
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) {
            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("V2Ray Reality Protocol", color = Color.White)
                Switch(checked = true, onCheckedChange = {}, colors = SwitchDefaults.colors(checkedThumbColor = PowerOnColor, checkedTrackColor = PowerOnColor.copy(alpha=0.5f)))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) {
            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("WireGuard Obfuscation", color = Color.White)
                Switch(checked = false, onCheckedChange = {}, colors = SwitchDefaults.colors(checkedThumbColor = PowerOnColor, checkedTrackColor = PowerOnColor.copy(alpha=0.5f)))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = CardColor)) {
            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Kill Switch", color = Color.White)
                Switch(checked = true, onCheckedChange = {}, colors = SwitchDefaults.colors(checkedThumbColor = PowerOnColor, checkedTrackColor = PowerOnColor.copy(alpha=0.5f)))
            }
        }
    }
}
